function LocalStorageManager(){
	
}

module.exports = LocalStorageManager;