# wxapp-2048
基于[web版2048游戏](https://github.com/gabrielecirulli/2048)开发的微信小程序版2048，仅作交流学习用。

### 界面展示

![游戏界面](./images/game.png)

### 使用方法

1. 克隆本项目
2. 在微信开发工具中添加项目
3. 选择项目目录

### 相关资源

- [2048游戏](https://github.com/gabrielecirulli/2048)
- [微信小程序资源](https://github.com/justjavac/awesome-wechat-weapp)
- [微信小程序开发教程手册](http://www.w3cschool.cn/weixinapp/9wou1q8j.html)